package assisted_project_3;

import java.util.LinkedList;
import java.util.Queue;

public class QueueAp3 
{
 
 public static void main(String[] args) {
  Queue<String> Queuelist= new LinkedList<String>();
  
  Queuelist.add("sakthi");
  Queuelist.add("abishek");
  Queuelist.add("gokul");
  Queuelist.add("sathya");
  Queuelist.add("aravind");
  Queuelist.add("Arun");
  
  System.out.println("Queue is : "+Queuelist);  
  //find head of queue
  System.out.println("Head of the Queue list : "+Queuelist.peek());
  Queuelist.remove();  
  System.out.println("After Removing Head: "+Queuelist);
  
 }

}