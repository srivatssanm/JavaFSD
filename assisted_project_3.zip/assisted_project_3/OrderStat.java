package assisted_project_3;

class Kth_Smallst 
{ 
int kthSmallestelement(int arr[], int a, int t, int k) 
    	{ 
             		if (k > 0 && k <= t - a + 1) 
        		{ 
            			int pos = randomPartition(arr, a, t); 
            			if (pos-a == k-1) 
                			return arr[pos]; 
            			if (pos-a > k-1) 
                			return kthSmallestelement(arr, a, pos-1, k); 
            			return kthSmallestelement(arr, pos+1, t, k-pos+a-1); 
        		} 
        return Integer.MAX_VALUE; 
    } 
    void swap(int arr[], int i, int j) 
    { 
        int temp = arr[i]; 
        arr[i] = arr[j]; 
        arr[j] = temp; 
    } 
    int partition(int arr[], int l, int r) 
    { 
        int x = arr[r], i = l; 
        for (int j = l; j <= r - 1; j++) 
        { 
            if (arr[j] <= x) 
            { 
                swap(arr, i, j); 
                i++; 
            } 
        } 
        swap(arr, i, r); 
        return i; 
    } 
    int randomPartition(int arr[], int l, int r) 
    { 
        int n = r-l+1; 
        int pivot = (int)(Math.random()) * (n-1); 
        swap(arr, l + pivot, r); 
        return partition(arr, l, r); 
    } 
}  
public class OrderStat
{
	public static void main(String[] args) {
		Kth_Smallst obj = new Kth_Smallst(); 
        int arr[] = {12, 1, 4, 8, 6, 19, 51}; 
        int n = arr.length,k = 4; 
        System.out.println("K'th smallest element is "+ obj.kthSmallestelement(arr, 0, n-1, k)); 
    }
}
