package assisted_project_3;



public class StackAp3 
{
  static final int MAX=1000;
  int  t;
  int arr[]= new int[MAX];
  
  boolean isEmpty() 
  {
   
   return t<0;
   
  }
  //constructor
  public StackAp3() 
  {
   t=-1;
  }
  
  //add an element to stack
  boolean push(int a) 
  {
   if(t>=(MAX-1))
   {
    System.out.println("Stack is Overflow");
    return false;
   }
   else 
   {
    arr[++t]=a;
    System.out.println(a+" Pushed into stack");
    return true;
   }
  }
  
  //removal of elements
  int pop() 
  {
   
   if(t<0) 
   {
    System.out.println("Statck  is UNDERFLOW");
    return 0;
   }
   else 
   {
    int x= arr[t--];
    return x;
   }   
  }
  
  public static void main(String[] args) 
  {
 StackAp3 s1=  new StackAp3();
   s1.push(15);
   s1.push(25);
   s1.push(38);
   s1.push(53);
   s1.push(60);
   
   System.out.println(s1.pop()+ " : Poped Out from stack");
  }

}