package com.simplilearn.demo;

import org.testng.annotations.Test;

public class firsttestdemo {
  @Test
  public void f() {
  }
}
