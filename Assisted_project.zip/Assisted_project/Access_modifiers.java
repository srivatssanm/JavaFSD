package Assisted_project;



public class Access_modifiers {

	
	public void Publicmethod() {
		System.out.println("This is public method");
	}
	
	private void Privatemethod() {
		System.out.println("This is private method");
	}
	
	void Defaultmethod() {
		System.out.println("This is default method");
	}
	
	protected void Protectedmethod() {
		System.out.println("This is protected method");
	}
	
	//same class able to access all types of modifiers
	public static void main(String [] args) {
		
		Access_modifiers obj= new  Access_modifiers();
		
		
		obj.Privatemethod();
		obj.Protectedmethod();
		obj.Publicmethod();
		obj.Defaultmethod();
		
	
	}
}