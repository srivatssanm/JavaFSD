package Assisted_project;



public class Constructors {		
		int student_Id;
		String student_Name;
		String department;
		float CGPA;
		
		//default constructor
		public Constructors() {
			student_Id=1001;
			student_Name="Gokul";
			department="EEE";
			CGPA=9;
		}
		
		//parameterized constructor
		public Constructors(int stuId,String stuName,String department,float CGPA) {
			this.student_Id=stuId;
			this.student_Name=stuName;
			this.department=department;
			this.CGPA=CGPA;
		}
		
		public void display() {
			System.out.println("Id: "+student_Id);
			System.out.println("Name: "+student_Name);
			System.out.println("Department: "+department);
			System.out.println("CGPA: "+CGPA);
			System.out.println();
			
		}
		
		public static void main(String[] args) {
			
			Constructors s= new Constructors();
			Constructors s1= new Constructors(121, "Rahul", "EEE", 8); 

			//calling default constructor
			s.display();
			//parameterized constructor
			s1.display();
			
			 
		
		}

		
	}