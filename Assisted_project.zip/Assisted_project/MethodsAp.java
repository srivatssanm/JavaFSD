package Assisted_project;

public class MethodsAp{
	
	//void method do not have return type
	 public void methodDisplay() {
		System.out.println("you called display method");
	 }
	 // int method must have return type
	 public int numberMethod() {
		 
		 int a=10;
		 return a;
	 }
	
	 public static void main(String[] args) {
		 
		 MethodsAp objt= new MethodsAp();
		 objt.methodDisplay();
		 
		 int result=objt.numberMethod();
		 
		 System.out.println(result);
		
	}
}