package Assisted_project;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		//creating array_list
		System.out.println("Array_List");
		ArrayList<String> cities=new ArrayList<String>();   
	      cities.add("Chennai");//
	      cities.add("Kumbakonam");    	   
	      System.out.println(cities);  
		
		//creating vector
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> vect = new Vector();
	      vect.addElement(20); 
	      vect.addElement(40); 
	      System.out.println(vect);
		
		//creating linked_list
	      System.out.println("\n");
	      System.out.println("Linked_List");
	      LinkedList<String> Names=new LinkedList<String>();  
	      Names.add("Karthi");  
	      Names.add("surya");  	      
	      Iterator<String> itr=Names.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       
	       //creating hash_set
	       System.out.println("\n");
	       System.out.println("Hash_Set");
	       HashSet<Integer> Hset=new HashSet<Integer>();  
	       Hset.add(201);  
	       Hset.add(203);  
	       Hset.add(202);
	       Hset.add(204);
	       System.out.println(Hset);
	       
	       //creating linked_hashset
	       System.out.println("\n");
	       System.out.println("Linked_HashSet");
	       LinkedHashSet<Integer> LHset2=new LinkedHashSet<Integer>();  
	       LHset2.add(11);  
	       LHset2.add(13);  
	       LHset2.add(12);
	       LHset2.add(14);	       
	       System.out.println(LHset2);
	      	} 
	      }  
	}
