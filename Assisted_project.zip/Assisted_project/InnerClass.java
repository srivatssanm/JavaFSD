package Assisted_project;

public class InnerClass {

	 private String message="Welcome to Java"; 
	 
	 class Inner{  
	  void hello(){System.out.println(message+", I learnt the inner class in java");}  
	 }  


	public static void main(String[] args) {

		InnerClass ob=new InnerClass();
		InnerClass.Inner in=ob.new Inner();  
		in.hello();  
	}
}

					
