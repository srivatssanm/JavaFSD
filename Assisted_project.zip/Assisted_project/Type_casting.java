package Assisted_project;

public class Type_casting {
	public static void main(String[] args) {
		
		//implicit type conversion
		System.out.println("Implicit --> Type Casting");
		char S1='A';
		System.out.println("Value of S1: "+S1);
		
		int S2=S1;
		System.out.println("Value of S2: "+S2);
		
		float S3=S1;
		System.out.println("Value of S3: "+S3);
		
		long S4=S1;
		System.out.println("Value of S4: "+S4);
		
		double S5=S1;
		System.out.println("Value of S5: "+S5);
		
				
		System.out.println("\n");
		
		System.out.println("Explicit --> Type Casting");
		//explicit Type conversion
		
		double A=60.5;
		int B=(int)A;
		System.out.println("Value of A: "+A);
		System.out.println("Value of B: "+B);
		
	}


}
