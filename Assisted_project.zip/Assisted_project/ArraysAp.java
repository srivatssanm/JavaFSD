package Assisted_project;

public class ArraysAp {

public static void main(String[] args) {

//single-dimensional array
int b[]= {10,20,30,40,50};
for(int i=0;i<5;i++) {
System.out.println("Elements of array a: "+b[i]);
}


//multidimensional array
int[][] c = {
            {2, 4, 6, 8}, 
            {3, 6, 9} };
      
      System.out.println("\nLength of row 1: " + c[0].length);
      }
}