package assisted_project_2;

public class SleepWait 
{
    private static Object LOCKING = new Object();
    public static void main(String args[]) throws InterruptedException
    {
        Thread.sleep(3000);
        System.out.println("Thread '" + Thread.currentThread().getName() + "' is get woken after 3 second of sleeping ");
        synchronized (LOCKING) 
        {
        	LOCKING.wait(3000);
            System.out.println("Obj '" + LOCKING + "' is woken after" + " 3 second of waiting");
        }
    }
}
