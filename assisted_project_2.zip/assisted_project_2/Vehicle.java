package assisted_project_2;

public class Vehicle 
{  
    String Type; 
    String Brand; 
    int Model; 
    String color; 
    public Vehicle(String type, String brand, int model, String color) 
    { 
        this.Type = type; 
        this.Brand = brand; 
        this.Model = model; 
        this.color = color; 
    } 
    public String gettype() 
    { 
        return Type; 
    } 
    public String getbrand() 
    { 
        return Brand; 
    } 
    public int getmodel() 
    { 
        return Model; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi Vehicle type is ---> "+ this.gettype()+ ".\nMy Brand,Model and color are ---> " + this.getbrand()+", " + this.getmodel()+ ", and "+ this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        Vehicle scott = new Vehicle("Four Wheeler","Benz", 2022, "Shiny Red"); 
        System.out.println(scott.toString()); 
    } 
}
