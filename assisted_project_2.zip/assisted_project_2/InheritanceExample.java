package assisted_project_2;


class Bike{ 
    public int gear; 
    public int speed; 
    public Bike(int gear, int speed) 
    { 
        this.gear = gear; 
        this.speed = speed; 
    } 
    public void applyBrake(int decrement) 
    { 
        speed =speed- decrement; 
    } 
    public void speedUp(int increment) 
    { 
        speed =speed+ increment; 
    }  
    public String toString()  
    { 
        return("No of gears are --> " + gear + "\n" + "speed of bike is -->" + speed); 
    }  
} 
class Honda extends Bike  
{ 
    public int seatHeight; 
    public Honda(int gear,int speed,int startHeight) 
    {  
        super(gear, speed); 
        seatHeight = startHeight; 
    }  
    public void setHeight(int newValue) 
    { 
        seatHeight = newValue; 
    } 
    @Override
    public String toString() 
    { 
        return (super.toString()+ 
                "\nseat height is --> "+seatHeight); 
    } 
}
public class InheritanceExample 
{ 
    public static void main(String args[])  
    { 
        Honda h1 = new Honda(3, 100, 25); 
        System.out.println(h1.toString());
    } 
}