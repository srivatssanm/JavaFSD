package assisted_project_2;

class PolyExample 
{
    public int sum(int x, int y) 
    { 
        return (x + y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    } 
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
    	PolyExample s1 = new PolyExample(); 
        System.out.println(s1.sum(30, 20)); 
        System.out.println(s1.sum(15, 30, 45)); 
        System.out.println(s1.sum(15.5, 20.5)); 
    } 
}
