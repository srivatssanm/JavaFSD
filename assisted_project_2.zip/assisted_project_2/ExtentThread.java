package assisted_project_2;

public class ExtentThread extends Thread
{
 	public void run()
 	{
  		System.out.println("concurrent thread is executing..");
}
 	public static void main( String args[] )
 	{
 		ExtentThread mt = new  ExtentThread();
  		mt.start();
 	}
}
