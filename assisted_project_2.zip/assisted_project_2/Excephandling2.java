package assisted_project_2;



public class Excephandling2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			try{
				
				System.out.println(5/0);
			}
			catch(ArithmeticException e){
				e.printStackTrace();
			}
			finally{
				System.out.println("End of the program");
			}
			System.out.println("Hello All!!!");
	}

}