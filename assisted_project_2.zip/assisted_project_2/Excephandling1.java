package assisted_project_2;

;

public class Excephandling1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			try{
				System.out.println(5/0);
				//throw new ArithmeticException();
			}
			catch(ArithmeticException e){
				e.printStackTrace();
			}
			System.out.println("Hello Folks!!!");
	}

}