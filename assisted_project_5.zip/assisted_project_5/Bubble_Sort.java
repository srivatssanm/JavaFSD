package assisted_project_5;

public class Bubble_Sort {


    public static void main(String[] args){

     int[] arr1= {100,80,40,60,20};
     bubbleSort(arr1);
     for(int i=0;i<arr1.length;i++){

        System.out.println(arr1[i]);
        }
    }

    public static void bubbleSort(int[] arr){
        int len = arr.length;
        int temp = 0;
        for(int i=0;i<len;i++){
            for (int j=1;j<(len);j++){
                if(arr[j-1]>arr[j]){
                temp = arr[j-1];
                arr[j-1]= arr[j];
                arr[j]= temp;

                }


            }

        }

    }

}
