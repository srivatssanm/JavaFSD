package assisted_project_5;

import java.util.Scanner;

public class LinearSearchAlgo {

    public static void main(String[] args){

        int[] arr = {20,40,60,80,100};

        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter the element to be searched");
        int searchValue = s1.nextInt();
            int result = (int) linearing(arr,searchValue);

            if(result==-1){

                System.out.println("Element not in the array");
            } else {

                System.out.println("Element found at "+result+" and the search key is "+arr[result]);
            }


        }




public static int linearing(int arr[], int x) {

    int array_length = arr.length;
    for (int i = 0; i < array_length - 1; i++) {

        if (arr[i] == x) {

            return i;

         }
     }

            return -1;

   }

}
