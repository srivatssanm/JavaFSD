package assisted_project_5;

public class BinarySearchAlgo {

    public static  void main(String[] args){


        int[] Arr = {4,8,12,16,20};
        int key = 12;
        int arrlength = Arr.length;
        binarySearch(Arr,0,key,arrlength);
    }

public static void binarySearch(int[] arr, int start, int key, int length){

        int mid_Value = (start+length)/2;
        while(start<=length){

            if(arr[mid_Value]<key){

                start = mid_Value + 1;
            } else if(arr[mid_Value]==key){
                System.out.println("Element is found at index :"+mid_Value);
                break;
            }else {

                length=mid_Value-1;
            }
            mid_Value = (start+length)/2;
        }
            if(start>length){

                System.out.println("Element is not found");
            }

}

}
